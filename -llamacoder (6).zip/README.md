# Resume Editor - Professional CV Builder

A modern, responsive resume editor with real-time preview, multiple templates, and print optimization.

## Features

- ✨ **Real-time Editing** - See changes instantly as you type
- 🎨 **3 Professional Templates** - Classic, Modern, and Compact layouts
- 🎯 **Print Optimization** - Perfect PDF output with dedicated print styles
- 🌈 **Background Colors** - 6 preset colors for personalization
- 💾 **Auto-save** - Data persists in localStorage
- 📱 **Responsive Design** - Works on desktop and mobile
- 🖨️ **Print-Ready** - Optimized for professional printing

## Quick Start

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Installation
\`\`\`bash
# Clone the repository
git clone https://github.com/your-username/resume-editor.git
cd resume-editor

# Install dependencies
npm install

# Start development server
npm start
\`\`\`

Open [http://localhost:3000](http://localhost:3000) to view the app.

## Build & Deploy

### Build for Production
\`\`\`bash
npm run build
\`\`\`

### Deployment Options

#### 1. Vercel (Recommended)
\`\`\`bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
\`\`\`
Or connect your GitHub repository to [Vercel](https://vercel.com) for automatic deployments.

#### 2. Netlify
\`\`\`bash
# Install Netlify CLI
npm i -g netlify-cli

# Deploy
netlify deploy --prod --dir=build
\`\`\`
Or drag and drop the \`build\` folder to [Netlify](https://netlify.com).

#### 3. GitHub Pages
\`\`\`bash
# Install gh-pages
npm install --save-dev gh-pages

# Deploy
npm run deploy:gh-pages
\`\`\`

#### 4. Any Static Hosting
Upload the \`build\` folder to any static hosting service.

## Project Structure

\`\`\`
src/
├── components/
│   ├── ui/           # Shadcn UI components
│   ├── BackgroundPicker.tsx
│   ├── EditorPanel.tsx
│   ├── ResumePreview.tsx
│   └── TemplateSelector.tsx
├── types/
│   └── resume.ts     # TypeScript interfaces
├── utils/
│   └── resumeData.ts # Default data
└── App.tsx           # Main application
\`\`\`

## Usage

1. **Edit Your Resume** - Fill in all sections in the editor panel
2. **Choose Template** - Select from Classic, Modern, or Compact layouts
3. **Customize Colors** - Pick a background color that suits your style
4. **Preview & Print** - Use the print button to generate a PDF-ready resume

## Technologies Used

- **React 18** - Modern React with hooks
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Shadcn UI** - Beautiful UI components
- **Framer Motion** - Smooth animations
- **Lucide React** - Professional icons

## Contributing

1. Fork the repository
2. Create a feature branch (\`git checkout -b feature/amazing-feature\`)
3. Commit your changes (\`git commit -m 'Add amazing feature'\`)
4. Push to the branch (\`git push origin feature/amazing-feature\`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

If you have any questions or feedback, please open an issue on GitHub.