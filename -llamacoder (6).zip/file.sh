npm run build
npm run serve