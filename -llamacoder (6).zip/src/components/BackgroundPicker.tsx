import { backgroundColors } from '../utils/resumeData';
import { Button } from '../components/ui/button';

interface BackgroundPickerProps {
  selected: string;
  onChange: (color: string) => void;
}

export function BackgroundPicker({ selected, onChange }: BackgroundPickerProps) {
  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium text-gray-700">Background Color</h3>
      <div className="grid grid-cols-3 gap-2">
        {backgroundColors.map((color) => (
          <Button
            key={color.value}
            variant={selected === color.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => onChange(color.value)}
            className="flex items-center gap-2 justify-start"
          >
            <div className={`w-4 h-4 rounded border ${color.value}`}></div>
            <span className="text-xs">{color.name}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}