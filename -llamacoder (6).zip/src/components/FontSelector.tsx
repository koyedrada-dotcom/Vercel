import { FontSettings } from '../types/resume';
import { fontFamilies, fontSizes } from '../utils/resumeData';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';

interface FontSelectorProps {
  settings: FontSettings;
  onChange: (settings: FontSettings) => void;
}

export function FontSelector({ settings, onChange }: FontSelectorProps) {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <h3 className="text-sm font-medium text-gray-700">Font Family</h3>
        <Select value={settings.family} onValueChange={(value) => onChange({ ...settings, family: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select font" />
          </SelectTrigger>
          <SelectContent>
            {fontFamilies.map((font) => (
              <SelectItem key={font.value} value={font.class}>
                <span className={font.class}>{font.name}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium text-gray-700">Font Size</h3>
        <div className="flex gap-2">
          {Object.entries(fontSizes).map(([key, size]) => (
            <Button
              key={key}
              variant={settings.size === key ? 'default' : 'outline'}
              size="sm"
              onClick={() => onChange({ ...settings, size: key as 'small' | 'medium' | 'large' })}
              className="flex-1"
            >
              {size.name}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}