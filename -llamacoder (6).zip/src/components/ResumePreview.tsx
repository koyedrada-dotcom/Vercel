import { ResumeData, TemplateType, FontSettings } from '../types/resume';
import { fontSizes } from '../utils/resumeData';
import { Mail, Phone, MapPin, Globe } from 'lucide-react';

interface ResumePreviewProps {
  data: ResumeData;
  template: TemplateType;
  backgroundColor: string;
  fontSettings: FontSettings;
}

export function ResumePreview({ data, template, backgroundColor, fontSettings }: ResumePreviewProps) {
  const currentFontSize = fontSizes[fontSettings.size];
  const fontClass = fontSettings.family;

  const ClassicTemplate = () => (
    <div className={`flex min-h-full ${fontClass}`}>
      <div className="w-1/3 bg-gray-900 text-white p-8">
        <h1 className={`font-bold mb-2 ${currentFontSize.titleClass}`}>{data.personalInfo.name}</h1>
        <p className="text-gray-300 mb-6">{data.personalInfo.title}</p>
        
        <div className="space-y-4 mb-6">
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4" />
            <span className={currentFontSize.class}>{data.personalInfo.phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            <span className={currentFontSize.class}>{data.personalInfo.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span className={currentFontSize.class}>{data.personalInfo.location}</span>
          </div>
          {data.personalInfo.website && (
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              <span className={currentFontSize.class}>{data.personalInfo.website}</span>
            </div>
          )}
        </div>

        <div className="mb-6">
          <h2 className={`font-semibold mb-3 ${currentFontSize.headingClass}`}>Skills</h2>
          <div className="flex flex-wrap gap-2">
            {data.skills.map((skill, index) => (
              <span key={index} className="px-2 py-1 bg-gray-800 rounded text-xs">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-auto pt-6 border-t border-gray-700">
          <p className={`text-center ${currentFontSize.class} underline decoration-2 underline-offset-4`}>
            {data.personalInfo.name}
          </p>
          <p className={`text-center text-gray-400 mt-2 ${currentFontSize.class}`}>Applicant Signature</p>
        </div>
      </div>
      
      <div className="flex-1 p-8">
        <div className="mb-6">
          <h2 className={`font-bold text-gray-900 mb-3 ${currentFontSize.titleClass}`}>Professional Summary</h2>
          <p className={`text-gray-700 leading-relaxed ${currentFontSize.class}`}>{data.summary}</p>
        </div>

        <div className="mb-6">
          <h2 className={`font-bold text-gray-900 mb-3 ${currentFontSize.titleClass}`}>Work Experience</h2>
          {data.workExperience.map((exp) => (
            <div key={exp.id} className="mb-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className={`font-semibold text-gray-900 ${currentFontSize.class}`}>{exp.title}</h3>
                  <p className={`text-gray-700 ${currentFontSize.class}`}>{exp.company} • {exp.location}</p>
                </div>
                <span className={`text-gray-600 ${currentFontSize.class}`}>{exp.startDate} - {exp.endDate}</span>
              </div>
              <p className={`text-gray-600 leading-relaxed ${currentFontSize.class}`}>{exp.description}</p>
            </div>
          ))}
        </div>

        <div>
          <h2 className={`font-bold text-gray-900 mb-3 ${currentFontSize.titleClass}`}>Education</h2>
          {data.education.map((edu) => (
            <div key={edu.id} className="mb-3">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className={`font-semibold text-gray-900 ${currentFontSize.class}`}>{edu.degree}</h3>
                  <p className={`text-gray-700 ${currentFontSize.class}`}>{edu.school} • {edu.location}</p>
                </div>
                <span className={`text-gray-600 ${currentFontSize.class}`}>{edu.startDate} - {edu.endDate}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const ModernTemplate = () => (
    <div className={`p-10 ${fontClass}`}>
      <header className="mb-8 text-center">
        <h1 className={`font-light text-gray-900 mb-2 ${fontSettings.size === 'large' ? 'text-4xl' : fontSettings.size === 'medium' ? 'text-3xl' : 'text-2xl'}`}>
          {data.personalInfo.name}
        </h1>
        <p className={`text-gray-600 mb-4 ${fontSettings.size === 'large' ? 'text-xl' : fontSettings.size === 'medium' ? 'text-lg' : 'text-base'}`}>
          {data.personalInfo.title}
        </p>
        <div className={`flex justify-center gap-6 text-gray-600 ${currentFontSize.class}`}>
          <span>{data.personalInfo.location}</span>
          <span>•</span>
          <span>{data.personalInfo.phone}</span>
          <span>•</span>
          <span>{data.personalInfo.email}</span>
          {data.personalInfo.website && (
            <>
              <span>•</span>
              <span>{data.personalInfo.website}</span>
            </>
          )}
        </div>
      </header>

      <section className="mb-8">
        <h2 className={`font-semibold text-gray-900 mb-3 uppercase tracking-wide ${currentFontSize.headingClass}`}>Summary</h2>
        <p className={`text-gray-700 leading-relaxed ${currentFontSize.class}`}>{data.summary}</p>
      </section>

      <section className="mb-8">
        <h2 className={`font-semibold text-gray-900 mb-3 uppercase tracking-wide ${currentFontSize.headingClass}`}>Experience</h2>
        {data.workExperience.map((exp) => (
          <div key={exp.id} className="mb-6">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className={`font-semibold text-gray-900 ${currentFontSize.class}`}>{exp.title}</h3>
                <p className={`text-gray-600 ${currentFontSize.class}`}>{exp.company} | {exp.location}</p>
              </div>
              <span className={`text-gray-500 ${currentFontSize.class}`}>{exp.startDate} - {exp.endDate}</span>
            </div>
            <p className={`text-gray-700 leading-relaxed ${currentFontSize.class}`}>{exp.description}</p>
          </div>
        ))}
      </section>

      <section className="mb-8">
        <h2 className={`font-semibold text-gray-900 mb-3 uppercase tracking-wide ${currentFontSize.headingClass}`}>Education</h2>
        {data.education.map((edu) => (
          <div key={edu.id} className="mb-3">
            <div className="flex justify-between items-start">
              <div>
                <h3 className={`font-semibold text-gray-900 ${currentFontSize.class}`}>{edu.degree}</h3>
                <p className={`text-gray-600 ${currentFontSize.class}`}>{edu.school} | {edu.location}</p>
              </div>
              <span className={`text-gray-500 ${currentFontSize.class}`}>{edu.startDate} - {edu.endDate}</span>
            </div>
          </div>
        ))}
      </section>

      <section className="mb-8">
        <h2 className={`font-semibold text-gray-900 mb-3 uppercase tracking-wide ${currentFontSize.headingClass}`}>Skills</h2>
        <div className="flex flex-wrap gap-3">
          {data.skills.map((skill, index) => (
            <span key={index} className={`px-4 py-2 bg-gray-100 text-gray-700 rounded-full ${currentFontSize.class}`}>
              {skill}
            </span>
          ))}
        </div>
      </section>

      <section className="text-center pt-6 border-t border-gray-200">
        <p className={`text-gray-700 underline decoration-2 underline-offset-4 ${currentFontSize.class}`}>
          {data.personalInfo.name}
        </p>
        <p className={`text-gray-600 mt-2 ${currentFontSize.class}`}>Applicant Signature</p>
      </section>
    </div>
  );

  const CompactTemplate = () => (
    <div className={`p-6 ${fontClass}`}>
      <header className="mb-4">
        <h1 className={`font-bold text-gray-900 ${fontSettings.size === 'large' ? 'text-2xl' : fontSettings.size === 'medium' ? 'text-xl' : 'text-lg'}`}>
          {data.personalInfo.name}
        </h1>
        <p className={`text-gray-600 ${currentFontSize.class}`}>{data.personalInfo.title}</p>
        <div className={`flex gap-4 mt-2 text-gray-600 ${currentFontSize.class}`}>
          <span>{data.personalInfo.phone}</span>
          <span>{data.personalInfo.email}</span>
          <span>{data.personalInfo.location}</span>
        </div>
      </header>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-4">
          <section>
            <h2 className={`font-semibold text-gray-900 mb-2 ${currentFontSize.headingClass}`}>Summary</h2>
            <p className={`text-gray-700 ${currentFontSize.class}`}>{data.summary}</p>
          </section>

          <section>
            <h2 className={`font-semibold text-gray-900 mb-2 ${currentFontSize.headingClass}`}>Experience</h2>
            {data.workExperience.map((exp) => (
              <div key={exp.id} className="mb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className={`font-medium text-gray-900 ${currentFontSize.class}`}>{exp.title}</h3>
                    <p className={`text-gray-600 ${currentFontSize.class}`}>{exp.company} • {exp.location}</p>
                  </div>
                  <span className={`text-gray-500 ${currentFontSize.class}`}>{exp.startDate} - {exp.endDate}</span>
                </div>
                <p className={`text-gray-600 mt-1 ${currentFontSize.class}`}>{exp.description}</p>
              </div>
            ))}
          </section>

          <section>
            <h2 className={`font-semibold text-gray-900 mb-2 ${currentFontSize.headingClass}`}>Education</h2>
            {data.education.map((edu) => (
              <div key={edu.id} className="mb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className={`font-medium text-gray-900 ${currentFontSize.class}`}>{edu.degree}</h3>
                    <p className={`text-gray-600 ${currentFontSize.class}`}>{edu.school} • {edu.location}</p>
                  </div>
                  <span className={`text-gray-500 ${currentFontSize.class}`}>{edu.startDate} - {edu.endDate}</span>
                </div>
              </div>
            ))}
          </section>
        </div>

        <div className="space-y-4">
          <section>
            <h2 className={`font-semibold text-gray-900 mb-2 ${currentFontSize.headingClass}`}>Skills</h2>
            <div className="space-y-1">
              {data.skills.map((skill, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                  <span className={`text-gray-700 ${currentFontSize.class}`}>{skill}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="pt-4 border-t border-gray-200">
            <p className={`text-gray-700 underline decoration-2 underline-offset-4 ${currentFontSize.class}`}>
              {data.personalInfo.name}
            </p>
            <p className={`text-gray-600 mt-2 ${currentFontSize.class}`}>Applicant Signature</p>
          </section>
        </div>
      </div>
    </div>
  );

  return (
    <div className={`${backgroundColor} min-h-screen print:min-h-auto print:shadow-none`}>
      <div className="max-w-4xl mx-auto bg-white shadow-lg print:shadow-none">
        {template === 'classic' && <ClassicTemplate />}
        {template === 'modern' && <ModernTemplate />}
        {template === 'compact' && <CompactTemplate />}
      </div>
    </div>
  );
}