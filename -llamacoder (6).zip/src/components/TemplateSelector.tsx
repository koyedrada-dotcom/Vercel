import { TemplateType } from '../types/resume';
import { Button } from '../components/ui/button';

interface TemplateSelectorProps {
  selected: TemplateType;
  onChange: (template: TemplateType) => void;
}

export function TemplateSelector({ selected, onChange }: TemplateSelectorProps) {
  const templates = [
    { id: 'classic' as TemplateType, name: 'Classic', description: 'Sidebar layout with dark accent' },
    { id: 'modern' as TemplateType, name: 'Modern', description: 'Clean centered design' },
    { id: 'compact' as TemplateType, name: 'Compact', description: 'Space-efficient two-column' }
  ];

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium text-gray-700">Template</h3>
      <div className="flex gap-2">
        {templates.map((template) => (
          <Button
            key={template.id}
            variant={selected === template.id ? 'default' : 'outline'}
            size="sm"
            onClick={() => onChange(template.id)}
            className="flex-1"
          >
            {template.name}
          </Button>
        ))}
      </div>
    </div>
  );
}