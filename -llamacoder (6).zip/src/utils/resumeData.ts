import { ResumeData } from '../types/resume';

export const defaultResumeData: ResumeData = {
  personalInfo: {
    name: 'John Doe',
    title: 'Senior Software Engineer',
    phone: '+1 (555) 123-4567',
    email: 'john.doe@example.com',
    location: 'San Francisco, CA',
    website: 'johndoe.dev'
  },
  summary: 'Experienced software engineer with 8+ years in full-stack development. Passionate about building scalable web applications and leading cross-functional teams.',
  workExperience: [
    {
      id: '1',
      title: 'Senior Software Engineer',
      company: 'Tech Corp',
      location: 'San Francisco, CA',
      startDate: '2021',
      endDate: 'Present',
      description: 'Lead development of microservices architecture serving 10M+ users. Mentored junior developers and improved system performance by 40%.'
    },
    {
      id: '2',
      title: 'Software Engineer',
      company: 'StartupXYZ',
      location: 'New York, NY',
      startDate: '2018',
      endDate: '2021',
      description: 'Built RESTful APIs and React applications. Implemented CI/CD pipelines reducing deployment time by 60%.'
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Bachelor of Science in Computer Science',
      school: 'University of California, Berkeley',
      location: 'Berkeley, CA',
      startDate: '2014',
      endDate: '2018'
    }
  ],
  skills: ['JavaScript', 'TypeScript', 'React', 'Node.js', 'Python', 'AWS', 'Docker', 'PostgreSQL']
};

export const backgroundColors = [
  { name: 'White', value: 'bg-white' },
  { name: 'Light Gray', value: 'bg-gray-50' },
  { name: 'Soft Blue', value: 'bg-blue-50' },
  { name: 'Cream', value: 'bg-amber-50' },
  { name: 'Light Green', value: 'bg-green-50' },
  { name: 'Off-White', value: 'bg-stone-50' }
];

export const fontFamilies = [
  { name: 'Inter', value: 'font-sans', class: 'font-inter' },
  { name: 'Georgia', value: 'font-serif', class: 'font-georgia' },
  { name: 'Roboto', value: 'font-sans', class: 'font-roboto' },
  { name: 'Open Sans', value: 'font-sans', class: 'font-opensans' },
  { name: 'Lato', value: 'font-sans', class: 'font-lato' },
  { name: 'Merriweather', value: 'font-serif', class: 'font-merriweather' }
];

export const fontSizes = {
  small: {
    name: 'Small',
    class: 'text-xs',
    headingClass: 'text-sm',
    titleClass: 'text-base'
  },
  medium: {
    name: 'Medium',
    class: 'text-sm',
    headingClass: 'text-base',
    titleClass: 'text-lg'
  },
  large: {
    name: 'Large',
    class: 'text-base',
    headingClass: 'text-lg',
    titleClass: 'text-xl'
  }
};